import React from 'react';

import ViewImageScreen from './components/app/ViewImageScreen';

import WelcomeScreen from './components/app/ WelcomeScreen';
export default function App() {
  return (
   //  <ViewImageScreen/>
    <WelcomeScreen/>
  );
}



