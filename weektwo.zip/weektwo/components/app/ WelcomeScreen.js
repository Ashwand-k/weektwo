import React from 'react';
import { ImageBackground,StyleSheet,View,Image,Text,TouchableOpacity} from 'react-native';
import Button from '../Button';
function WelcomeScreen(props) {
    return (
        <ImageBackground
          blurRadius={1.5} style = { styles.background}
       
        source={require("../../assets/background.jpg")}>
            <View style={styles.logoandtext}>
            <Image style={styles.logocss} source={require("../../assets/logo-red.png")}></Image>
            <Text>Sell wat you dont need</Text>
            </View>
            
           <Button
           label={"login"}
           />
           <Button
           label={"register"}
           style={{  backgroundColor:"#4ecdc4",}}
           />
             
        </ImageBackground>
    );
}
const styles = StyleSheet.create({
    background:{
        flex:1,
        justifyContent:'flex-end',
        alignItems:'center',
         blurRadius:"2"
    },
    
    logocss:{
        width:100,
        height:100,
       alignItems:'center'
       
    },
    logoandtext:{
       
        position:"absolute",
        top:80,
       
    }
})

export default WelcomeScreen;