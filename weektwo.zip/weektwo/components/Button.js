import React from 'react';
import { View,
Text,
TouchableOpacity,
StyleSheet
 } from 'react-native';

const Button = ({label ,style}) =>{
    return(
         <TouchableOpacity
             style={[styles.Buttoncontainer,style]}
             >
             <Text
             style={styles.textcontainer}>
             {label}
             </Text>
             
             </TouchableOpacity>
    )
};
const styles=StyleSheet.create({
  Buttoncontainer:{width:"90%",
             height:40,
             backgroundColor:"#fc5c65",
             borderRadius:40,
             alignItems:"center",
             justifyContent:"center",
             padding:'15',
             marginBottom:15,

             },
             textcontainer:{
               alignItems:"center",
               justifyContent:"center",
               fontSize:15,
               fontWeight:"bold",
               color:"white",
               
             }
})
export default Button;